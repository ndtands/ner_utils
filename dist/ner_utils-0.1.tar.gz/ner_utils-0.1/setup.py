from setuptools import setup, find_packages

setup(name='ner_utils',

      version='0.1',

      description='utils for NER NLP',

      author='ndtan',

      author_email='ndtan.hcm@gmail.com',

      packages = ['ner_utils'],

      zip_safe=False)